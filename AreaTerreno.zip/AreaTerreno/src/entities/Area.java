package entities;

public class Area {
	public double area;
	
	
	public void retornaArea(double largura, double comprimento) {
		area = largura * comprimento;
	}
}
