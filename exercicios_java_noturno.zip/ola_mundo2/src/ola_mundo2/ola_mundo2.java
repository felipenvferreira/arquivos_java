package ola_mundo2;

public class ola_mundo2 {

	public static void main(String[] args) {
		System.out.println("Ol� mundo!");

	}

}
